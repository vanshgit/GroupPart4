package exercise2;

 abstract class GameTester {
	protected String name;
    protected boolean FullTime;

    public GameTester(String name, boolean FullTime) {
        this.name = name;
        this.FullTime = FullTime;
    }
    public String getName() {
        return name;
    }

    public boolean FullTime() {
        return FullTime;
    }


    public abstract double determineSalary(int hours);
}
