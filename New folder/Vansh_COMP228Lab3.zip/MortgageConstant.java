package exercise3;

public interface MortgageConstant {
	
		 final int SHORTTERM = 1;
		 final int MEDTERM=3;
		 final int LONGTERM=5;
		 final int MAXIMUMLOANAMOUTN=300000;
		 final String BANKNAME="TorontoCityBank";

}
