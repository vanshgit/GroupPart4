/**
 * 
 */
/**
 * @author vansh
 *
 */
module Vansh_COMP228Lab3 {
	requires java.desktop;
}