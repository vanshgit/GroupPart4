package exercise2;

public class FullTimeGameTester extends GameTester {
	public FullTimeGameTester(String name) {
	       super(name, true);
	   }
	public double determineSalary(int hours) {
	       return 3000;
	   }
	}



