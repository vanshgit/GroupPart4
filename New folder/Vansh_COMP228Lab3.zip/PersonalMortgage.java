package exercise3;

public class PersonalMortgage extends Mortgage {
	 public PersonalMortgage(int mortgageNumber,
	 String customerName,
	 double amountOfMortgage,
	 double interestRate, int term) {
	 super(mortgageNumber, customerName, amountOfMortgage, interestRate, term);
	 setAmountOfMortgage(getInterestRate()+2);
	 }
	 // override 
	 public String toString() {
	 return "Personal Mortgage: Mortgage number:" + this.getMortgageNumber() +" "+
	 "Amount of loan:$" + this.getAmountOfMortgage() +" "+
	 "Customer Name:" + this.getCustomerName() +" "+
	 "Interest Rate:" + this.getInterestRate() +" "+
	 "Term of Loan:" + this.getTerm();
	 }
	}