package exercise2;

public class PartTimeGameTester extends GameTester {
	
	

	   public PartTimeGameTester(String name) {
	       super(name, false);
	      
	   }

	   // override 
	   public double determineSalary(int hours) {
	       return 20 * hours;
	   }

}
