package exercise1;

public class Life extends Insurance {
	public Life(String typeOfInsurance, double monthlyCost) {
		 super ( typeOfInsurance , monthlyCost );
		 }
		 
		 public double setInsuranceCost(double monthlyCost) {
		this.monthlyCost=monthlyCost;
		 return monthlyCost;
		 }
		 
		 public void displayInfo() {
		 System.out.println("Type of insurance: "+this.getTypeOfInsurance()+"\n Insurance Cost: "  +this.getMonthlyCost());
		 }
	
}
