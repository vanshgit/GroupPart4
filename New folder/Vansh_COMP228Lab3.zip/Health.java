package exercise1;

public class Health extends Insurance  {
	
	public Health(String typeOfInsurance, double monthlyCost) {
		 super(typeOfInsurance, monthlyCost);
		 }
		 
		 public double setInsuranceCost(double monthlyCost) {
		 //monthlyCost=monthlyCost;
		 return monthlyCost;
		 }
		 
		 public void displayInfo() {
			 System.out.println("Type of insurance: "+this.getTypeOfInsurance()+"\n  Insurance Cost: "   +this.getMonthlyCost());
					  }

		 }

