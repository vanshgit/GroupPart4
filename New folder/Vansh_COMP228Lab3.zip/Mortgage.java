package exercise3;

public abstract class Mortgage implements MortgageConstant {
    // Instance variables for Mortgage class
    private int mortgageNumber;
    private String customerName;
    private double amountOfMortgage;
    private double interestRate;
    private int term;
    
    // Constructor for Mortgage class
    public Mortgage(int mortgageNumber, String customerName, double amountOfMortgage, double interestRate,int term){
        this.mortgageNumber=mortgageNumber;
        this.customerName=customerName;
        this.amountOfMortgage=amountOfMortgage;
        this.interestRate=interestRate;
        this.term=term;
    }
    
    // Getter method for mortgageNumber
    public int getMortgageNumber(){
        return mortgageNumber;
    }
    
    // Setter method for mortgageNumber
    public void setMortgageNumber(){
        this.mortgageNumber=mortgageNumber;
    }
    
    // Getter method for customerName
    public String getCustomerName(){
        return customerName;
    }
    
    // Setter method for customerName
    public void setCustomerName(){
        this.customerName=customerName;
    }
    
    // Getter method for amountOfMortgage
    public double getAmountOfMortgage(){
        return amountOfMortgage;
    }
    
    // Setter method for amountOfMortgage
    public void setAmountOfMortgage(double interestRate){
        if (amountOfMortgage>MAXIMUMLOANAMOUTN){
            System.out.println("Mortgage amount should not be greater than $300,000");
        } else {
            this.amountOfMortgage=amountOfMortgage;
        }
    }
    
    // Getter method for interestRate
    public double getInterestRate(){
        return interestRate;
    }
    
    // Setter method for interestRate
    public void setInterestRate(){
        this.interestRate=interestRate;
    }
    
    // Getter method for term
    public int getTerm(){
        return term;
    }
    
    // Setter method for term
    public void setTerm(){
        if(term<3)
            this.term= SHORTTERM;
        else if (term==3)
            this.term=MEDTERM;
        else
            this.term=LONGTERM;
    }
    
    // Method to get mortgage information as a String
    public String getMortgageInfo(){
        return "[mortgageNumber =" + mortgageNumber +" "+
        ",customerName=" + customerName +" "+
        ", amount=" + amountOfMortgage +" "+
        ", interestRate=" + interestRate +" "+
        ", term=" + term + "]";
    }
    
    // Override toString method to return a custom String for Mortgage object
    public String toString(){
        return "Mortgage number: "+ mortgageNumber +" "+
        "Amount of loan: "+amountOfMortgage+" "+
        "Customer Name: " + customerName +" "+
        "Interest Rate: " + interestRate+" "+
        "Term of Loan in years:"+ term;
    }
}
