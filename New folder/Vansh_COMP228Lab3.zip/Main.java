package exercise1;
import java.util.*;

public class Main {

	public static void main(String[] args) {
		Insurance[] insurances=new Insurance[3];
		 Scanner scanner=new Scanner(System.in);
		 String selection ="";
		 double enterCost;
		 for(int i=0;i<2;i++) {
		 System.out.println("Please select type of Insurance :" +
		 "\n Life " +
		"\n Health ");
		 selection = scanner.next().toLowerCase();
		 if (selection.equals("life")) {
		 System.out.println("Please enter the cost of Insurance:");
		 enterCost = scanner.nextDouble();
		 Health health = new Health(selection, enterCost);
		 insurances[i] = health;
		 // health.displayInfo();
		//
		 } else {
		 System.out.println("Please enter the cost of Insurance:");
		 enterCost = scanner.nextDouble();
		 Life life = new Life(selection, enterCost);
		 insurances[i] = life;
		 //life.displayInfo();
		 }
		 }
		 for (Insurance myInsurance:
		 insurances) {
		 System.out.println(myInsurance);
	}
		 }
	}



