package exercise2;
import java.util.*;

public class Main {

    public static void main(String[] args) {
        // Create a Scanner object for user input
        Scanner sc = new Scanner(System.in);

        // Ask the user to enter the name of the game tester
        System.out.print("Enter tester's name: ");
        String name = sc.nextLine();

        // Ask the user if the game tester is full-time or part-time
        System.out.print("Is the tester full-time? (yes/no): ");
        String isFullTime = sc.nextLine();

        // Create a GameTester object
        GameTester tester;
        
        // If the game tester is full-time
        if (isFullTime.equalsIgnoreCase("yes")) {
            // Create a FullTimeGameTester object
            tester = new FullTimeGameTester(name);
        } 
        // If the game tester is part-time
        else {
            // Ask the user to enter the number of hours the part-time tester works
            System.out.print("Enter the number of hours: ");
            int hours = sc.nextInt();
            // Create a PartTimeGameTester object
            tester = new PartTimeGameTester(name);
            // Print the part-time tester's salary
            System.out.println("Salary is: $" + tester.determineSalary(hours));
            // Close the Scanner object
            sc.close();
            return;
        }
        // Print the full-time tester's salary
        System.out.println("Salary is: $" + tester.determineSalary(0));

        // Close the Scanner object
        sc.close();
    }
}
