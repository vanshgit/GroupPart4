package exercise3;
import java.util.*;
public class Main {

	public static void main(String[] args) {
		 Mortgage[] mortgages=new Mortgage[3];
		 Scanner scanner=new Scanner(System.in);
		 int selection =0;
		 int mortgageNumber;
		 String name;
		 double amountOfLoan;
		 double interestRate;
		 int term;
		 for(int i=0;i<3;i++){
		 System.out.println("Please select type of mortgage :" +
		 "\n 1: Business Mortgage " +
		"\n 0: Personal Mortgage");
		 selection=scanner.nextInt();
		 if(selection==1){
		 System.out.println("Please enter a number:");
		 mortgageNumber=scanner.nextInt();
		 System.out.println("Please enter your name:");
		 name=scanner.next();
		 System.out.println("PLease enter amount of loan:");
		 amountOfLoan=scanner.nextDouble();
		 System.out.println("Please enter interest rate:");
		 interestRate=scanner.nextDouble();
		 System.out.println("Please enter term:");
		 term=scanner.nextInt();
		 BusinessMortgage businessMortgage= new
		BusinessMortgage(mortgageNumber,name,
		 amountOfLoan,interestRate,term);
		 mortgages[i]=businessMortgage;
		 }
		 else {
		 System.out.println("Please enter a number:");
		 mortgageNumber=scanner.nextInt();
		 System.out.println("Please enter your name:");
		 name=scanner.next();
		 System.out.println("PLease enter amount of loan:");
		 amountOfLoan=scanner.nextDouble();
		 System.out.println("Please enter interest rate:");
		 interestRate=scanner.nextDouble();
		 System.out.println("Please enter term:");
		 term=scanner.nextInt();
		 PersonalMortgage PersonalMortgage= new
		PersonalMortgage(mortgageNumber,name,
		 amountOfLoan,interestRate,term);
		 mortgages[i]=PersonalMortgage;
		 }
		 }
		 for (Mortgage myMortgage:mortgages
		 ) {
		 System.out.println(myMortgage);
		 }
		 }

		

	}

