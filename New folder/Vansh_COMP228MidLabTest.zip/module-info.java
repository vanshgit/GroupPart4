/**
 * 
 */
/**
 * @author vansh
 *
 */
module Vansh_COMP228MidLabTest {
	requires java.desktop;
	
}