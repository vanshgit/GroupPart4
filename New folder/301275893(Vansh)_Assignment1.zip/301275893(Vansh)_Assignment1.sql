/*Problem 1 */
/*1. Produce a list of sentencing information to include criminal ID, full name, sentence ID, sentence start date, and the length in months of the sentence. 
The number of months should be shown as a whole number. That start date should be displayed in the format �January 1, 2023� [2 marks]*/

SELECT CR.Criminal_id, CR.First ||' '|| CR.Last as Name, S.Sentence_ID, S.Start_date
FROM Sentences S
JOIN Criminals CR ON S.Criminal_id = CR.Criminal_id;


/*Problem 2 */
/* List the name of each officer who has reported more than the average number of crimes officers have reported */
SELECT CO.OFFICER_ID, O.LAST ||  '  '  || O.FIRST as Name 
FROM CRIME_OFFICERS CO 
JOIN OFFICERS O ON CO.OFFICER_ID =
O.OFFICER_ID 
GROUP BY CO.OFFICER_ID, O.LAST, O.FIRST HAVING
COUNT(*) > (SELECT COUNT(*) / COUNT(DISTINCT OFFICER_ID) FROM
CRIME_OFFICERS );


/*Problem 3 */
/*3. List the names of all criminals who have committed less than average number of crimes and aren�t listed as violent offenders [2 marks] */

SELECT B.LAST||' '|| B.FIRST as Name, A.CRIMINAL_ID, A.NO_OF_CRIME
FROM (SELECT CRIMINAL_ID, COUNT(CRIME_ID) 
AS NO_OF_CRIME
FROM CRIMES GROUP BY CRIMINAL_ID) A, CRIMINALS B
WHERE B.CRIMINAL_ID=A.CRIMINAL_ID
AND A.NO_OF_CRIME <
(SELECT AVG(NO_OF_CRIME)
FROM (SELECT CRIME_ID,
COUNT(CHARGE_ID) AS NO_OF_CRIME FROM CRIME_CHARGES
GROUP BY CRIME_ID))
AND B.V_STATUS='N';
         
         /*Problem 4 */
/*4. List appeal information for each appeal that has longer than the average number of days between the filing and hearing dates [2 marks]*/

SELECT * FROM appeals
Having AVG((filing_date - hearing_date))
=ALL(SELECT AVG((filing_date - hearing_date))
FROM appeals)
GROUP BY appeal_id, crime_id, filing_date, hearing_date, status;

/*Problem 5 */
/*5. List the names of probation officers who have had less than average number of criminals assigned [2 marks]*/

SELECT prob_id, last, first, COUNT(DISTINCT(criminal_id)) criminals 
FROM prob_officers 
NATURAL JOIN sentences
HAVING COUNT(prob_id) > (SELECT
AVG(COUNT(DISTINCT(criminal_id)))
FROM sentences GROUP BY prob_id)
GROUP BY prob_id, last, first;

          
          /*Problem 6 */
/*6. List each crime that has had the least number of appeals recorded [2 marks]*/
SELECT * 
FROM crimes 
WHERE crime_id 
IN (SELECT crime_id 
FROM appeals 
GROUP BY crime_id
HAVING COUNT(crime_id) <= (SELECT MAX(COUNT(crime_id))
FROM appeals GROUP BY crime_id));

/*7. List the following information for all crimes that have a period longer than 10 days between the data charged and the hearing date: crime ID,
classification, date charged, hearing date, and the number of days between the date charged and the hearing date [2 marks] */
SELECT crime_id, classification, date_charged, hearing_date,
       (hearing_date - date_charged) AS days_between
FROM crimes
WHERE hearing_date - date_charged > 10;


