package exercise1;

public class Main {

	public static void main(String[] args) {
		  Test test = new Test(); 

	       test.inputAnswer(); 

	}

}
