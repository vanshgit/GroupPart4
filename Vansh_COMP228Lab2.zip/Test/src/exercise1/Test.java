package exercise1;
import javax.swing.JOptionPane; 

import java.util.Random; 

 

public class Test { 

	private final String[] questions = { 
		    "Question 1: What is the keyword used to define a class in Java?", 
		    "Question 2: What does the keyword 'static' mean in Java?", 
		    "Question 3: How is encapsulation achieved in Java?", 
		    "Question 4: What is an Interface in Java?", 
		    "Question 5: How is polymorphism achieved in Java?" 
		}; 

		private final String[][] options = { 
		    {"1. class", "2. def", "3. Class", "4. ClassDef"},
		    {"1. It makes a method or variable belong to the class, not an instance", "2. It makes a method or variable immutable", "3. It prevents a method from being overridden", "4. It indicates that a variable can be accessed from anywhere"},
		    {"1. By using public variables and methods", "2. By using package-private variables and methods", "3. By using private variables and methods, and public getters/setters", "4. By using static variables and methods"},
		    {"1. A class that cannot be instantiated", "2. A contract that specifies a group of related methods with empty bodies", "3. A parent class from which other classes inherit", "4. A class that can only contain static methods"},
		    {"1. By using only methods that are declared in the current class", "2. By using the 'poly' keyword", "3. By using interfaces and/or extending classes and overriding methods", "4. By using only static methods"} 
		}; 

		private final int[] correctAnswers = {1, 1, 3, 2, 3};


 

   private int correct_count = 0; 

   private int incorrect_count = 0; 

 

   private Random random = new Random(); 

 

   public void simulateQuestion(int questionIndex) { 

       String message = questions[questionIndex] + "\n"; 

       for (int i = 0; i < options[questionIndex].length; i++) { 

           message += options[questionIndex][i] + "\n"; 

       } 

       JOptionPane.showMessageDialog(null, message); 

   } 

public boolean checkAnswer(int questionIndex, int answer) { 

       if (answer == correctAnswers[questionIndex]) { 

           correct_count++; 

           JOptionPane.showMessageDialog(null, generateMessage(true)); 

           return true; 

       } else { 

           incorrect_count++; 

           JOptionPane.showMessageDialog(null, generateMessage(false) + " The correct answer is: " + 

                   options[questionIndex][correctAnswers[questionIndex]]); 

           return false; 

       } 

   } 

 

   public String generateMessage(boolean isCorrect) { 

       int randomIndex = random.nextInt(4); 

       switch (randomIndex) { 

           case 0: 

               return isCorrect ? "Excellent!" : "No. Please try again"; 

           case 1: 

               return isCorrect ? "Good!" : "Wrong. Try once more"; 

           case 2: 

               return isCorrect ? "Keep up the good work!" : "Don't give up!"; 

           case 3: 

               return isCorrect ? "Nice work!" : "No. Keep trying..."; 

           default: 

               return ""; 

       } 

   } 

 

   public void inputAnswer() { 

       for (int i = 0; i < questions.length; i++) { 

           simulateQuestion(i); 

           int answer = 0; 

           boolean validInput = false; 

 

           while (!validInput) { 

               try { 

                   answer = Integer.parseInt(JOptionPane.showInputDialog("Enter the number of your answer:")); 

                   validInput = true; 

               } catch (NumberFormatException e) { 

                   JOptionPane.showMessageDialog(null, "Invalid input. Please enter a number."); 

               } 

           } 

 

      checkAnswer(i, answer); 

       } 

   double percentage = (double) correct_count / questions.length * 100; 

      JOptionPane.showMessageDialog(null, "Test completed!\n" + 

               "Correct answers: " + correct_count + "\n" + 

         "Incorrect answers: " + incorrect_count + "\n" + 

               "Percentage: " + percentage + "%"); 

   } 

 


} 
