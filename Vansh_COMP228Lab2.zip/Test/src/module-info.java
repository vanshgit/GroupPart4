/**
 * 
 */
/**
 * @author vansh
 *
 */
module Test {
	requires java.desktop;
}