package exercise3;

public class OlMethod {

	    public static int multiply(int num1, int num2) {
	        return num1 * num2;
	    }

	
	    public static int multiply(int num1, int num2, int num3) {
	        return num1 * num2 * num3;
	    }

	  
	    public static double multiply(double num1, double num2) {
	        return num1 * num2;
	    }

	    public static void main(String[] args) {
	        System.out.println("Multiplication of two integers: " + multiply(4, 2));
	        System.out.println("Multiplication of three integers: " + multiply(2, 3, 4));
	        System.out.println("Multiplication of two doubles: " + multiply(2.5, 3.5));
	    }
	}


