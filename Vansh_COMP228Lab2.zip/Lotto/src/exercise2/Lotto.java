package exercise2;
import java.util.Random;
import javax.swing.JOptionPane;

public class Lotto {
    private int[] values;

    public Lotto() {
        values = new int[3];
        Random random = new Random();
        for (int i = 0; i < values.length; i++) {
            values[i] = random.nextInt(9) + 1;
        }
    }

    public int[] getValues() {
        return values;
    }

    public int getSum() {
        int sum = 0;
        for (int value : values) {
            sum += value;
        }
        return sum;
    }

    public static void main(String[] args) {
        String input = JOptionPane.showInputDialog("Enter a number between 3 and 27:");
        int userNumber = Integer.parseInt(input);

        boolean win = false;
        for (int i = 0; i < 5; i++) {
            Lotto lotto = new Lotto();
            int sum = lotto.getSum();
            if (sum == userNumber) {
                win = true;
                break;
            }
        }

        if (win) {
            JOptionPane.showMessageDialog(null, "Congratulations! You won the game!");
        } else {
            JOptionPane.showMessageDialog(null, "Sorry! The computer won the game.");
        }
    }
}
