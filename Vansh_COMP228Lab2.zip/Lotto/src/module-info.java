/**
 * 
 */
/**
 * @author vansh
 *
 */
module Lotto {
	requires java.desktop;
}